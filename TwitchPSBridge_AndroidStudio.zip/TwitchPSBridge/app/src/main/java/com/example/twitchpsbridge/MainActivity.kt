package com.example.twitchpsbridge

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.net.URI
import java.util.concurrent.Executors
import okhttp3.*

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private var socket: WebSocket? = null
    private lateinit var channel: EditText
    private lateinit var status: TextView
    private val seen = mutableSetOf<String>()
    private val codeRegex = Regex("(?i)(?<![A-Z0-9])([A-Z0-9]{4})[- ]?([A-Z0-9]{4})[- ]?([A-Z0-9]{4})(?![A-Z0-9])")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 28) }
        layout.addView(TextView(this).apply { text = "Twitch → PlayStation"; textSize = 24f })
        layout.addView(TextView(this).apply { text = "Escribe el canal público de Twitch. Mantén PlayStation en la pantalla de canje y enfoca primero su casilla de código." })
        channel = EditText(this).apply { hint = "Canal de Twitch"; singleLine = true }
        layout.addView(channel)
        val start = Button(this).apply { text = "Iniciar detector"; setOnClickListener { connect() } }
        layout.addView(start)
        layout.addView(Button(this).apply { text = "Activar permiso de accesibilidad"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        layout.addView(Button(this).apply { text = "Detener"; setOnClickListener { socket?.close(1000, "user stopped"); status.text = "Detector detenido" } })
        status = TextView(this).apply { text = "Estado: detenido"; textSize = 16f; gravity = Gravity.CENTER_VERTICAL }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "Importante: esta versión inicial solo intenta rellenar el campo que esté enfocado. No pulsa Continue ni confirma el canje. El permiso de accesibilidad es sensible: actívalo solo si confías en esta app."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun connect() {
        val name = channel.text.toString().trim().removePrefix("#").lowercase()
        if (!name.matches(Regex("[a-z0-9_]{1,25}"))) { status.text = "Escribe un canal válido"; return }
        seen.clear()
        status.text = "Conectando a #$name…"
        val request = Request.Builder().url("https://irc-ws.chat.twitch.tv:443").build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send("PASS SCHMOOPIIE")
                webSocket.send("NICK justinfan${(100000..999999).random()}")
                webSocket.send("JOIN #$name")
                runOnUiThread { status.text = "Conectado a #$name. Esperando códigos…" }
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                text.split("\\r\\n").forEach { line ->
                    if (line.startsWith("PING ")) { webSocket.send("PONG " + line.removePrefix("PING ")); return@forEach }
                    if (!line.contains(" PRIVMSG ")) return@forEach
                    val msg = line.substringAfter(" :", "")
                    codeRegex.findAll(msg).forEach { match ->
                        val code = (match.groupValues[1] + match.groupValues[2] + match.groupValues[3]).uppercase()
                        synchronized(seen) {
                            if (seen.add(code)) {
                                PsAccessibilityService.pendingCode = code
                                PsAccessibilityService.requestFill = true
                                runOnUiThread { status.text = "Detectado: $code · intentando rellenar el campo enfocado" }
                            }
                        }
                    }
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { status.text = "Error de conexión: ${t.message ?: "desconocido"}" }
            }
        })
    }
}
