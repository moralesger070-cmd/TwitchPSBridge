package com.example.twitchpsbridge

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

class PsAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var pendingCode: String? = null
        @Volatile var requestFill: Boolean = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!requestFill) return
        val code = pendingCode ?: return
        val root = rootInActiveWindow ?: return
        val focused = findFocusedEditable(root) ?: return
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) {
            requestFill = false
            pendingCode = null
        }
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused && node.isEditable && node.isEnabled) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFocusedEditable(child)
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() {}
}
