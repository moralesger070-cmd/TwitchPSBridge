# Twitch PS Bridge — prototipo Android

Proyecto fuente inicial para Android Studio. No es un APK instalado ni una versión probada en un Galaxy A07.

## Qué hace
- Se conecta al chat público de un canal de Twitch por IRC WebSocket.
- Busca cadenas que parezcan códigos de 12 caracteres (XXXX-XXXX-XXXX).
- Cuando encuentra uno, intenta escribirlo en el campo de texto editable que esté enfocado en la ventana activa.
- No pulsa Continue ni confirma el canje.

## Requisitos
- Android Studio reciente con JDK 17.
- Android SDK 35.
- Dependencia OkHttp añadida en `app/build.gradle.kts` antes de compilar:
  `implementation("com.squareup.okhttp3:okhttp:4.12.0")`

## Prueba
1. Abre el proyecto en Android Studio y añade la dependencia OkHttp indicada.
2. Compila e instala en tu Galaxy A07.
3. Abre la app y habilita su servicio en Ajustes > Accesibilidad.
4. En PlayStation App, abre canjear código y toca la casilla para dejarla enfocada.
5. Vuelve a la app, escribe el canal y pulsa Iniciar detector.
6. Cuando aparezca un código válido en el chat, la app intentará rellenar el campo enfocado.

## Limitaciones importantes
- Es un prototipo: la app puede no lograr escribir en campos de PlayStation App si Android o la app bloquean `ACTION_SET_TEXT`, si el campo no está enfocado o si la interfaz cambia.
- La pantalla dividida y el cambio entre apps se gestionan manualmente por Android.
- El chat puede no permitir conexiones anónimas o Twitch puede cambiar su protocolo.
- La detección por patrón puede confundir otros textos con códigos. Revisa el código antes de canjear.
- El permiso de accesibilidad puede observar e interactuar con la interfaz. Usa solo código fuente que puedas revisar; no se recopilan credenciales ni se pulsa confirmar.
